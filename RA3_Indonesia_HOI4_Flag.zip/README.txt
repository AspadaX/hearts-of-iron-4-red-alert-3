RA3 Empire of the Rising Sun — Indonesia flag for Hearts of Iron IV
=================================================================

Design:
- Indonesia's red (top) and white (bottom) horizontal bands remain intact.
- The authentic RA3 Empire of the Rising Sun emblem comes from the user-uploaded
  reference, with the red seal and white glyph preserved.
- The seal is centered over the dividing line with a thin white ring for
  sufficient contrast against the red upper band.

HOI4 game assets (all 32-bit uncompressed TGA):
    gfx/flags/INS.tga          82 x 52
    gfx/flags/medium/INS.tga   41 x 26
    gfx/flags/small/INS.tga    10 x 7

Usage: Copy gfx/ into your mod directory. The filenames use HOI4's INS
country tag for Indonesia. For cosmetic tags or ideology-specific flags,
rename INS.tga to the appropriate <tag>.tga or <tag>_<ideology>.tga
in each of the three directories.

Preview: RA3_Indonesia_Flag_Preview.png; optional PNGs under previews/.
